using UnityEngine;

// Definicja kluczy dost�pnych w grze
public enum KeyColor
{
    Red = 0,
    Green = 1,
    Blue = 2
}

public class KeyItem : MonoBehaviour
{
    // Konkretny kolor klucza w unity
    public KeyColor keyColor;
}