using UnityEngine;

public class WaypointFollower : MonoBehaviour
{
    // Tablica punkt�w kontrolnych
    [SerializeField] private GameObject[] waypoints;

    // Indeks bie��cego punktu
    private int currentWaypointIndex = 0;

    // Pr�dko�� poruszania si�
    [SerializeField] private float speed = 2.0f;

    void Update()
    {
        // 1. Oblicz odleg�o�� do bie��cego punktu
        if (Vector2.Distance(waypoints[currentWaypointIndex].transform.position, transform.position) < 0.1f)
        {
            // 2. Je�li jeste�my blisko, zwi�ksz indeks (modulo zap�tla tras�)
            currentWaypointIndex++;
            if (currentWaypointIndex >= waypoints.Length)
            {
                currentWaypointIndex = 0;
            }
        }

        // 3. Przesu� platform� w stron� punktu
        transform.position = Vector2.MoveTowards(
            transform.position,
            waypoints[currentWaypointIndex].transform.position,
            speed * Time.deltaTime
        );
    }
}